_G = GLOBAL
GLOBAL.setfenv(1, GLOBAL)

setmetatable(STRINGS.NAMES, {
    __index = function(t, k)
        return ""
    end
})

local function Proxy(name)
    local _fn = rawget(_G, name)
    local proxy = function(item, ...)
        if item ~= nil and startsWith(item, DEFAULT_PREFIX) then
            item = string.sub(item, #DEFAULT_PREFIX + 1)
        end
        return _fn(item,...)
    end
    rawset(_G, name, proxy)
end

Proxy("GetColorForItem")
Proxy("GetSkinDescription")
Proxy("GetSkinDescription")
Proxy("GetSkinName")
Proxy("GetSkinInvIconName")
Proxy("GetModifiedRarityStringForItem")


local inv_replica = require("components/inventoryitem_replica")
local _SetImage = inv_replica.SetImage
function inv_replica.SetImage(self, item)
    if item ~= nil and startsWith(item, DEFAULT_PREFIX) then
        item = string.sub(item, #DEFAULT_PREFIX + 1)
    end
    _SetImage(self, item)
end

if _G.TheNet:GetIsClient() then
    require("characterutil")
    local _SetSkinnedOvalPortraitTexture = SetSkinnedOvalPortraitTexture
    function SetSkinnedOvalPortraitTexture(image_widget, character, skin)
        if startsWith(skin, DEFAULT_PREFIX) then
            return
        end
        return _SetSkinnedOvalPortraitTexture(image_widget, character, skin)
    end
end

SKIN_RARITY_COLORS["ModMade"]   = { 72 / 255, 208 / 255, 208 / 255, 1 } --#48D0D0
SKIN_RARITY_COLORS["ModLocked"] = { 186 / 255, 7 / 255, 98 / 255, 1 }   --#BA0762
MODSKINANNOUNCEMENT_COLOR       = { 64 / 255, 219 / 255, 234 / 255, 1 }

local modded_order              = { ModMade = 31, ModLocked = 32 }
local _oldCompareRarities       = CompareRarities
CompareRarities                 = function(a, b)
    local rarity1 = GetRarityForItem(a)
    local rarity2 = GetRarityForItem(b)

    if modded_order[rarity1] or modded_order[rarity2] then
        local rarity1_sort = modded_order[rarity1] and modded_order[rarity1] or 1
        local rarity2_sort = modded_order[rarity2] and modded_order[rarity2] or 1

        return rarity1_sort < rarity2_sort
    end
    return _oldCompareRarities(a, b)
end

function RegisterNoneSkin(skin_id, base_prefab)
    if not PREFAB_SKINS[base_prefab] then PREFAB_SKINS[base_prefab] = {} end
    if not PREFAB_SKINS_IDS[base_prefab] then PREFAB_SKINS_IDS[base_prefab] = {} end
    if not PREFAB_SKINS_IDS[base_prefab][skin_id] then
        local key = #PREFAB_SKINS[base_prefab] + 1
        PREFAB_SKINS[base_prefab][key] = skin_id
        PREFAB_SKINS_IDS[base_prefab][skin_id] = key
    end
end

function ReplaceSkin(skin_id, new_skin_id, base_prefab)
    if base_prefab and PREFAB_SKINS[base_prefab] then
        if PREFAB_SKINS_IDS[base_prefab][skin_id] then
            local index = PREFAB_SKINS_IDS[base_prefab][skin_id]
            PREFAB_SKINS_IDS[base_prefab][skin_id] = nil
            PREFAB_SKINS_IDS[base_prefab][new_skin_id] = index
            PREFAB_SKINS[base_prefab][index] = new_skin_id
        end
    end
end
