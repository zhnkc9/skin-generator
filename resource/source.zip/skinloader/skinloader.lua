local _env = env
_G.setfenv(1, _G)

local MODDEDSKINS_VIGNETTE_ASSETS = {}

local MODDEDSKINSLOADED = false

local haspopulated = false

--=================================

local ModdedSkins = {
    ModMade = {},
    ModLocked = {},
    Character = {},
}

_env.IsModdedSkin = function(skin_id)
    return ModdedSkins.ModMade[skin_id] ~= nil or ModdedSkins.ModLocked[skin_id] ~= nil
end

local SKIN_AFFINITY_INFO = require("skin_affinity_info")


--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
local function is_type_loading(data)
    return data.type == "loading"
end

local function is_type_feet(data)
    return data.type == "body" or data.type == "hand" or data.type == "legs" or
        data.type == "feet"
end

local function is_type_emoji(data)
    return data.type == "emoji"
end

local function register_string(tbl, skin)
    if STRINGS[tbl][skin] == nil then
        local skinname = skin:sub(4, #skin)
        if STRINGS[tbl][skinname] == nil then
            STRINGS[tbl][skin] = STRINGS[tbl].MS_DEFAULT
        else
            STRINGS[tbl][skin] = STRINGS[tbl][skinname]
        end
    end
end

local function wrap_default_string(skin_id, data)
    if data.type == "base" or is_type_feet(data) then
        local affinity = data.affinity ~= nil and data.affinity or data.base_prefab or ""
        if affinity then
            if not SKIN_AFFINITY_INFO[affinity] then SKIN_AFFINITY_INFO[affinity] = {} end
            table.insert(SKIN_AFFINITY_INFO[affinity], skin_id)
        end
        register_string("SKIN_QUOTES", skin_id)
    end
    register_string("SKIN_NAMES", skin_id)
    register_string("SKIN_DESCRIPTIONS", skin_id)
end

local function wrap_skin_data(skin_id, data)
    if data.skin_tags == nil then data.skin_tags = {} end

    if not table.contains(data.skin_tags, "MODDED") then
        table.insert(data.skin_tags, "MODDED")
    end
    if is_type_feet(data) then
        if not table.contains(data.skin_tags, "CLOTHING") then
            table.insert(data.skin_tags, "CLOTHING")
        end
        if not table.contains(data.skin_tags, "CLOTHING_" .. string.upper(data.type)) then
            table.insert(data.skin_tags, "CLOTHING_" .. string.upper(data.type))
        end
    elseif is_type_loading(data) and not table.contains(data.skin_tags, "LOADING") then
        table.insert(data.skin_tags, "LOADING")
    elseif is_type_emoji(data) and not table.contains(data.skin_tags, "EMOJI") then
        table.insert(data.skin_tags, "EMOJI")
    end
    data.rarity = "ModMade"
    data.rarity_modifier = "Modded"
    data.skip_item_gen = true
    data.skip_giftable_gen = true
    return skin_id, data
end

local function registerSkin(skin_id, data)
    if startsWith(skin_id, DEFAULT_PREFIX) then
        local _skin_id = string.sub(skin_id, #DEFAULT_PREFIX + 1)
        local c = TheInventory:CheckOwnership(_skin_id)
        if not c then
            ReplaceSkin(_skin_id, skin_id, data.base_prefab)
        end
        ModdedSkins[data.rarity][skin_id] = true
        return
    end
    ModdedSkins[data.rarity][skin_id] = true
    if data.base_prefab == nil then return end
    RegisterNoneSkin(skin_id, data.base_prefab)
end

local function registerClothing(skin_id, data)
    CLOTHING[skin_id] = {
        type = data.type,
        skin_tags = data.skin_tags or nil,
        symbol_overrides = data.symbol_overrides or nil,
        symbol_hides = data.symbol_hides or nil,
        build_name_override = data.build_name_override or nil,
        rarity_modifier = "Modded",
        rarity = data.rarity,
        symbol_overrides_skinny = data.symbol_overrides_skinny or nil,
        symbol_overrides_mighty = data.symbol_overrides_mighty or nil,
        symbol_overrides_stage2 = data.symbol_overrides_stage2 or nil,
        symbol_overrides_stage3 = data.symbol_overrides_stage3 or nil,
        symbol_overrides_stage4 = data.symbol_overrides_stage4 or nil,
        symbol_overrides_powerup = data.symbol_overrides_powerup or nil,
        legs_cuff_size = data.legs_cuff_size or 1,
        feet_cuff_size = data.feet_cuff_size or 1,
        has_leg_boot = data.has_leg_boot or false,
        has_nub = data.has_nub or false,
        torso_tuck = data.torso_tuck or nil,
        symbol_in_base_hides = data.symbol_in_base_hides or nil,
        symbol_overrides_by_character = data.symbol_overrides_by_character or nil,
        release_group = data.release_group or 999,
    }
end

local function registerMiscItems(skin_id, data)
    MISC_ITEMS[skin_id] = {
        type = "loading",
        skin_tags = data.skin_tags,
        rarity = data.rarity,
        rarity_modifier = "Modded",
        release_group = data.release_group or 999,
    }
    local itemstate = Profile:GetCustomizationItemState(GetTypeForItem(skin_id), skin_id)
    if itemstate == nil then
        Profile:SetCustomizationItemState(GetTypeForItem(skin_id), skin_id, true)
    end
end

local function registerMiscOrEmoji(skin_id, data)
    SafeSkins[skin_id] = true
    MISC_ITEMS[skin_id] = {
        type = "emoji",
        skin_tags = data.skin_tags,
        rarity = data.rarity,
        rarity_modifier = "Modded",
        release_group = data.release_group or 999,
    }
    EMOJI_ITEMS[skin_id] = {
        rarity = data.rarity,
        rarity_modifier = "Modded",
        input_name = data.input_name or "UNKNOWN",
        type = "emoji",
        skin_tags = data.skin_tags,
        data =
        {
            item_type = skin_id,
            requires_validation = true,
            utf8_str = data.utf8_str,
        },
        release_group = data.release_group or 999,
    }
end

local function registerLoadingPrefab()
    if Settings.loading_screen_keys == nil then Settings.loading_screen_keys = {} end
    if not TheNet:IsOnlineMode() then return end
    for _, skins in pairs(ModdedSkins) do
        for skin, _ in pairs(skins) do
            local data = MISC_ITEMS[skin]
            if data ~= nil and is_type_loading(data) and Profile:GetCustomizationItemState(GetTypeForItem(skin), skin) then
                table.insert(Settings.loading_screen_keys, skin)
            end
        end
    end
end

--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

local _RegisterPrefabs = ModManager.RegisterPrefabs
ModManager.RegisterPrefabs = function(self)
    if not haspopulated then
        haspopulated = true
    end
    _RegisterPrefabs(self)

    MODDEDSKINSLOADED = true
end

function initializeModMain()
    local ModdedCurios = _env._ModdedCurios

    for skin_id, data in pairs(ModdedCurios) do
        skin_id, data = wrap_skin_data(skin_id, data)
        ModdedCurios[skin_id] = data
        wrap_default_string(skin_id, data)
        registerSkin(skin_id, data)

        for _, asset in pairs(data.assets or {}) do
            table.insert(_env.Assets, asset)
            if is_type_loading(data) and (asset.type == "IMAGE" or asset.type == "ATLAS") then
                table.insert(MODDEDSKINS_VIGNETTE_ASSETS, asset)
            end
        end

        if is_type_feet(data) then
            registerClothing(skin_id, data)
        elseif is_type_loading(data) then
            registerMiscItems(skin_id, data)
        elseif is_type_emoji(data) then
            registerMiscOrEmoji(skin_id, data)
        end
    end
end

local _CreatePrefabSkin = CreatePrefabSkin
CreatePrefabSkin = function(skin_id, data)
    if haspopulated and skin_id:sub(#skin_id - 4, #skin_id) ~= "_none" then
        skin_id, data = wrap_skin_data(skin_id, data)
        wrap_default_string(skin_id, data)
        registerSkin(skin_id, data)
        if data.type ~= "base" then
            local clear_fn = rawget(_G, data.base_prefab .. "_" .. "clear" .. "_fn")
            if not clear_fn then
                print("Local Collection Skins ERROR ,CAN NOT FIND THE INIT OR CLEAN FUNC", skin_id, data.base_prefab);
                rawset(_G, data.base_prefab .. "_" .. "clear" .. "_fn",
                    function(_inst) basic_clear_fn(_inst, _inst.prefab) end)
            end

            if (data.init_fn) then
                rawset(_G, skin_id .. "_" .. "init" .. "_fn", data.init_fn)
            end
        end
    elseif haspopulated and skin_id:sub(#skin_id - 4, #skin_id) == "_none" then
        RegisterNoneSkin(skin_id, data.base_prefab)
    end
    return _CreatePrefabSkin(skin_id, data)
end

local LoadingWidget = require("widgets/redux/loadingwidget")
local LoadingWidget_constructor = LoadingWidget._ctor
LoadingWidget._ctor = function(self, ...)
    local vignetteloader = Prefab("MODDEDSKIN_VIGNETTE_LOADER", nil, MODDEDSKINS_VIGNETTE_ASSETS, nil)
    RegisterPrefabs(vignetteloader)
    TheSim:LoadPrefabs({ vignetteloader.name })
    registerLoadingPrefab()
    LoadingWidget_constructor(self, ...)
end
local _RepickImage = LoadingWidget.RepickImage
function LoadingWidget:RepickImage(...)
    registerLoadingPrefab()
    if _RepickImage ~= nil then
        _RepickImage(self, ...)
    end
end

local _KeepAlive = LoadingWidget.KeepAlive
function LoadingWidget:KeepAlive(auto_increment, ...)
    TheSim:LoadPrefabs({ "MODDEDSKIN_VIGNETTE_LOADER" })
    if _KeepAlive ~= nil then
        _KeepAlive(self, auto_increment, ...)
    end
end

--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

local FNs = { rep = {}, pst = {} }
local function fns_call(name, fn, pst)
    local _fn = InventoryProxy[name]
    local replace = function() end
    if pst then
        replace = function(self, ...)
            local args = { _fn(self, ...) }
            local out = { fn(unpack(args)) }
            if next(out) then
                return unpack(out)
            end
            return unpack(args)
        end
    else
        replace = function(self, ...)
            local out = { fn(...) }
            if next(out) then
                return unpack(out)
            end
            return _fn(self, ...)
        end
    end
    InventoryProxy[name] = replace
end

local function checkClientOwnedSkins(skin_id, user_id)
    if _env.IsModdedSkin(skin_id) then
        return true
    end
end
FNs.rep.CheckOwnership = function(skin_id, user_id)
    return _env.IsModdedSkin(skin_id) and checkClientOwnedSkins(skin_id, user_id) or nil
end
FNs.rep.CheckClientOwnership = function(user_id, skin_id) return FNs.rep.CheckOwnership(skin_id, user_id) end
FNs.rep.CheckOwnershipGetLatest = function(skin_id)
    if _env.IsModdedSkin(skin_id) then
        return checkClientOwnedSkins(skin_id), 0
    end
end
FNs.rep.GetOwnedItemCount = function(skin_id)
    return _env.IsModdedSkin(skin_id) and (ModdedSkins.ModMade[skin_id] and 1 or 0) or nil
end
FNs.pst.GetFullInventory = function(inv, ...)
    for rarity, skins in pairs(ModdedSkins) do
        for skin, _ in pairs(skins) do
            if checkClientOwnedSkins(skin) then
                table.insert(inv, {
                    item_type = skin,
                    item_id = "0",
                    modified_time = -2147483647
                })
            end
        end
    end
    return inv
end
local _SetItemOpened = InventoryProxy.SetItemOpened
InventoryProxy.SetItemOpened = function(self, item_id, ...)
    if not _env.IsModdedSkin(item_id) then
        return _SetItemOpened(self, item_id, ...)
    end
end
for name, fn in pairs(FNs.rep) do fns_call(name, fn) end
for name, fn in pairs(FNs.pst) do fns_call(name, fn, true) end

local MODDEDSKIN_BUILDS = {}
_env.ApplyModdedSkin = function(_inst, name, skin)
    _inst.skinname = skin
    _inst.moddedskinname = skin
    local isGemPrefab, _, realprefab = name:find("^gemprefab_(.+)_%d+$")
    if isGemPrefab then
        name = realprefab
    end

    local _fn
    if (skin) then
        _fn = rawget(_G, skin .. "_" .. "init" .. "_fn") or
            rawget(_G, name .. "_" .. "init" .. "_fn")
    else
        _fn = rawget(_G, name .. "_clear_fn")
    end
    if not _fn then
        --print("Local Collection Skins ERROR ,CAN NOT FIND THE INIT OR CLEAN FUNC", skin, _inst.base_prefab);
        local def_build = _inst.AnimState:GetBuild()
        rawset(_G, name .. "_" .. "init" .. "_fn",
            function(__inst, build_name) basic_init_fn(__inst, build_name, def_build) end)
        _fn = rawget(_G, name .. "_" .. (skin and "init" or "clear") .. "_fn")
    end
    local build_name = (Prefabs[skin] ~= nil and Prefabs[skin].build_name_override) or skin

    if MODDEDSKIN_BUILDS[_inst.AnimState] then
        MODDEDSKIN_BUILDS[_inst.AnimState]:set(build_name or "")
    end
    _fn(_inst, build_name)
end

local _ReskinEntity = Sim.ReskinEntity
function Sim:ReskinEntity(targetGUID, currentskin, skin, idkwhat, userid, ...)
    _ReskinEntity(self, targetGUID, currentskin, skin, idkwhat, userid, ...)
    local inst = Ents[targetGUID]

    if inst == nil then return end

    if not table.contains(JoinArrays(DST_CHARACTERLIST, MODCHARACTERLIST), inst.prefab) then
        _env.ApplyModdedSkin(inst, inst.prefab, skin or nil)
    elseif skin == nil then
        if MODDEDSKIN_BUILDS[inst.AnimState] then
            MODDEDSKIN_BUILDS[inst.AnimState]:set("")
        end
    end
end
