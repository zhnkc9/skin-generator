local env = env

_G.setfenv(1, _G)

local _SpawnPrefab = SpawnPrefab
function SpawnPrefab(name, skin, ...)
    local ent = _SpawnPrefab(name, skin, ...)
    if ent and skin and startsWith(skin, DEFAULT_PREFIX) then
        name = name:gsub("_placer", "")
        env.ApplyModdedSkin(ent, name, skin)
    end
    return ent
end
